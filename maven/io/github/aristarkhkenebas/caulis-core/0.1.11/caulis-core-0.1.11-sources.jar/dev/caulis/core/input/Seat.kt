package dev.caulis.core.input

import dev.caulis.core.Surface
import dev.caulis.protocol.Client
import dev.caulis.protocol.Display
import dev.caulis.protocol.wayland.WlKeyboard
import dev.caulis.protocol.wayland.WlPointer
import dev.caulis.protocol.wayland.WlSeat
import dev.caulis.protocol.wayland.WlSurface
import dev.caulis.protocol.wayland.WlTouch
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * wl_seat: one keyboard and one pointer, as clients see them.
 *
 * The compositor decides who gets input ([focusKeyboard], [pointerMotion]); this class
 * turns that into the right events for the right client: enter/leave when focus moves,
 * keys and modifiers, motion, buttons and scrolling.
 */
class Seat(internal val display: Display, keymap: Keymap) : AutoCloseable {
    internal val touchSide = SeatTouch(this)
    internal val pointerSide = SeatPointer(this)

    /**
     * The keymap programs are given (see [setKeymap]). The seat owns it: it closes it when
     * another one replaces it, and when the seat itself is closed.
     */
    // (Careful: in initializers below, "keymap" alone is the constructor's argument, the first
    // keymap for ever — the handler of get_keyboard kept sending that one after it was
    // replaced and closed. Code that runs later uses sendKeymap, a function, where it is this.)
    var keymap: Keymap = keymap
        private set

    private val keyboards = ArrayList<WlKeyboard>()
    internal val pointers = ArrayList<WlPointer>()
    internal val touches = ArrayList<WlTouch>()
    private val seats = ArrayList<WlSeat>()

    /** A touch screen is there: programs are told the seat can touch (and get [touchDown] and the rest). */
    var touchScreen = false
        set(value) {
            if (field == value) return
            field = value
            seats.filter { it.isAlive }.forEach { it.sendCapabilities(capabilities()) }
        }

    private fun capabilities() = WlSeat.Capability.POINTER or WlSeat.Capability.KEYBOARD or (if (touchScreen) WlSeat.Capability.TOUCH else 0)
    private var keyboardState = keymap.newState()
    private val pressedKeys = LinkedHashSet<Int>()

    /** The surface that receives key presses (a window or popup), or null. */
    var keyboardFocus: Surface? = null
        private set

    /**
     * True if [client] has the keyboard, the pointer or the pen. The pointer counts even when
     * it merely passes over a program: to let a program act for the user (open a menu that
     * takes the keyboard, set the clipboard, start a drag) check [isInputSerial] instead.
     */
    fun inUse(client: dev.caulis.protocol.Client): Boolean =
        keyboardFocus?.resource?.client === client || pointerFocus?.resource?.client === client || penFocus?.resource?.client === client

    /**
     * True if [client] may set the clipboard (or the primary selection) now: [serial] is of
     * input the user gave it (a key, a click), or it has the keyboard. The pointer merely
     * passing over a program does not count (one in the background swapped what was copied).
     */
    fun maySetSelection(client: Client, serial: Int): Boolean =
        isInputSerial(client, serial) || keyboardFocus?.resource?.client === client

    // The serials of the last input events the user gave a program (keys, buttons, touches,
    // the keyboard coming to it), and which program that was. Moving the pointer over one is
    // not input: a program in the background that the pointer passes gets nothing here.
    private var inputClient: Client? = null
    private val inputSerials = ArrayDeque<Int>()

    // [client] was sent an input event with [serial] (see [isInputSerial]).
    internal fun inputSent(client: Client, serial: Int) {
        if (inputClient !== client) {
            inputClient = client
            inputSerials.clear()
        }
        inputSerials.addLast(serial)
        while (inputSerials.size > INPUT_SERIALS) inputSerials.removeFirst()
    }

    /**
     * True if [serial] is one of the last input events (a key, a mouse button, a touch, the
     * keyboard coming to it) sent to [client], and no other program got input since: a
     * request with it really answers what the user did there. Menus that take the keyboard,
     * the clipboard and window drags check this, so a program the pointer just passes over
     * cannot act on its own.
     */
    fun isInputSerial(client: Client, serial: Int): Boolean = inputClient === client && serial in inputSerials

    // The session locks: input given before does not count any more (the program that had the
    // keyboard cannot set the clipboard behind the lock with an old serial).
    internal fun forgetInput() {
        if (inputClient != null) focusLog.info("Input given before the lock does not count any more")
        inputClient = null
        inputSerials.clear()
    }

    private val keyboardFocusListeners = ArrayList<(Surface?) -> Unit>()

    /** Runs [listener] whenever the keyboard focus moves (e.g. to send the clipboard to the new client). */
    fun onKeyboardFocus(listener: (Surface?) -> Unit) {
        keyboardFocusListeners += listener
    }

    /** Held keys repeat this many times a second (0: never; 1 to 100). Programs repeat keys themselves; this tells them how. */
    var repeatRate = REPEAT_RATE
        set(value) {
            require(value in 0..100) { "repeatRate is 0 to 100 a second, not $value" }
            field = value
            repeatChanged()
        }

    /** How long a key is held before it repeats, in milliseconds (100 to 2000). */
    var repeatDelay = REPEAT_DELAY
        set(value) {
            require(value in 100..2000) { "repeatDelay is 100 to 2000 ms, not $value" }
            field = value
            repeatChanged()
        }

    private fun repeatChanged() {
        for (keyboard in keyboards) if (keyboard.version >= 4) keyboard.sendRepeatInfo(repeatRate, repeatDelay)
    }

    /** The surface under the pointer, or null. */
    var pointerFocus: Surface? = null
        internal set

    /**
     * Your own rule for which surfaces may get the keyboard and the pointer at all (all by
     * default). Whatever it says no to asks for the focus in vain (the keyboard stays where it
     * is), and keys never reach it — even if it had the focus before. The lock screen adds its
     * own rule on top (while the session is locked only the lock screen may), which this
     * cannot loosen and which unlocking does not reset.
     */
    var mayFocus: (Surface) -> Boolean = { true }
        set(value) {
            field = value
            focusRuleChanged()
        }

    // The lock screen's rule (set by Desktop): while locked only the lock's surfaces may.
    internal var lockAllows: (Surface) -> Boolean = { true }
        set(value) {
            field = value
            focusRuleChanged()
        }

    // True if [surface] may get the keyboard, the pointer or the pen now: the lock and [mayFocus] both say yes.
    internal fun allowed(surface: Surface): Boolean = lockAllows(surface) && mayFocus(surface)

    // A rule changed: whatever may not have the focus any more loses it.
    private fun focusRuleChanged() {
        keyboardFocus?.let { if (!allowed(it)) focusKeyboard(null) }
        pointerFocus?.let { if (!allowed(it)) pointerMotion(0, null, 0.0, 0.0) }
        penFocus?.let { if (!allowed(it)) penFocusLost(it) }
    }

    /** The cursor picture the client under the pointer drew itself (null = none: see [cursorShape]). */
    var cursorSurface: Surface? = null
        internal set

    /**
     * The point of [cursorSurface] that is the pointer's tip, from its top left corner in the
     * surface's units: the picture is drawn this far up and left of the pointer's position.
     */
    var cursorHotspotX = 0
        private set

    /** See [cursorHotspotX]. */
    var cursorHotspotY = 0
        private set

    /**
     * The cursor the client under the pointer asked for by name ("default", "text",
     * "pointer", ... see [dev.caulis.core.cursor.CursorTheme.SHAPES]), drawn from the cursor
     * theme. Null if it drew its own ([cursorSurface]) or hid the cursor.
     */
    var cursorShape: String? = "default"
        internal set

    /** Called when the cursor picture changes (the window manager redraws it). */
    var onCursorChange: () -> Unit = {}

    /**
     * The seat's name programs are told ("seat0" by default, as logind names the first seat).
     * Programs learn it when they bind the seat: set it before they start.
     */
    var name: String = "seat0"
        set(value) {
            if (value != field) focusLog.info { "The seat is called $value (programs binding it from now on hear it)" }
            field = value
        }

    // The keyboard's surface was destroyed under it: nobody has the keyboard now, and the window
    // manager decides who gets it next.
    internal var keyboardFocusDestroyed: (Surface) -> Unit = {}

    init {
        display.addGlobal(WlSeat, VERSION) { seat ->
            seat.requests = seatRequests
            seats += seat
            seat.onDestroy { seats -= seat }
            seat.sendCapabilities(capabilities())
            seat.sendName(name)
        }
    }

    private val seatRequests = object : WlSeat.Requests {
        override fun getPointer(resource: WlSeat, id: WlPointer) {
            pointers += id
            id.onDestroy { pointers -= id }
            id.requests = pointerRequests
        }

        override fun getKeyboard(resource: WlSeat, id: WlKeyboard) {
            keyboards += id
            id.onDestroy { keyboards -= id }
            id.requests = object : WlKeyboard.Requests {
                override fun release(resource: WlKeyboard) {}
            }
            sendKeymap(id)
            if (id.version >= 4) id.sendRepeatInfo(repeatRate, repeatDelay)
            // A keyboard created while its client already has focus starts focused.
            val focus = keyboardFocus
            if (focus != null && focus.resource.client === id.client) {
                val serial = display.nextSerial()
                id.sendEnter(serial, focus.resource, pressedKeysArray())
                inputSent(id.client, serial)
                sendModifiers(id)
            }
        }

        override fun getTouch(resource: WlSeat, id: WlTouch) {
            touches += id
            id.onDestroy { touches -= id }
            id.requests = object : WlTouch.Requests {
                override fun release(resource: WlTouch) {}
            }
        }

        override fun release(resource: WlSeat) {}
    }

    private val pointerRequests = object : WlPointer.Requests {
        override fun setCursor(resource: WlPointer, serial: Int, surface: WlSurface?, hotspotX: Int, hotspotY: Int) {
            // Only the client under the pointer may change the cursor.
            if (pointerFocus?.resource?.client !== resource.client) return
            val target = surface?.dataAs<Surface>()
            if (target != null && !target.assignRole(Surface.Role.CURSOR, resource, WlPointer.Error.ROLE)) return
            cursorSurface = target
            cursorHotspotX = hotspotX
            cursorHotspotY = hotspotY
            cursorShape = null
            onCursorChange()
        }

        override fun release(resource: WlPointer) {}
    }

    // A client asks for a cursor by name (cursor-shape-v1); only the one under the pointer may.
    internal fun setCursorShape(client: Client, shape: String) {
        if (pointerFocus?.resource?.client !== client) return
        cursorSurface = null
        cursorShape = shape
        onCursorChange()
    }

    // --- a pen over a program that takes tablet events ---------------------------------------

    /**
     * The surface a pen is over while its program gets tablet events (see [Tablets]); the
     * pointer has left it then, and this program says what the cursor looks like.
     */
    var penFocus: Surface? = null
        private set

    // Tablets hears of a surface that may not have the pen any more (the screen was locked).
    internal var penFocusLost: (Surface) -> Unit = {}

    // The pen came onto [surface] (null: away from tablet programs): the cursor is the default
    // one until that program sets its own.
    internal fun penEntered(surface: Surface?) {
        if (penFocus === surface) return
        penFocus = surface
        cursorSurface = null
        cursorShape = "default"
        if (surface != null) watchForDestruction(surface)
        onCursorChange()
    }

    // The program under the pen sets the cursor (zwp_tablet_tool_v2.set_cursor), as a pointer's would.
    internal fun setPenCursor(client: Client, surface: Surface?, hotspotX: Int, hotspotY: Int) {
        if (penFocus?.resource?.client !== client) return
        cursorSurface = surface
        cursorHotspotX = hotspotX
        cursorHotspotY = hotspotY
        cursorShape = null
        onCursorChange()
    }

    // The same by name (cursor-shape-v1 for a tablet tool).
    internal fun setPenCursorShape(client: Client, shape: String) {
        if (penFocus?.resource?.client !== client) return
        cursorSurface = null
        cursorShape = shape
        onCursorChange()
    }

    // --- keyboard ---------------------------------------------------------------------

    /**
     * Gives the keyboard to `surface` (null = nobody). A surface [mayFocus] (or the lock) refuses does not
     * get it, and the keyboard stays where it is (with the screen locked: the locker keeps it).
     */
    fun focusKeyboard(wanted: Surface?) {
        val old = keyboardFocus
        if (wanted != null && !allowed(wanted)) {
            focusLog.info { "Keyboard: ${wanted.roleObject ?: wanted} may not have it now; it stays with ${old?.roleObject ?: old ?: "nobody"}" }
            if (old == null || allowed(old)) return
        }
        val surface = wanted?.takeIf(::allowed)
        if (old === surface) return
        focusLog.trace { "Keyboard: ${old?.roleObject ?: old} → ${surface?.roleObject ?: surface}" }
        keyboardFocus = surface
        if (old != null && old.resource.isAlive) {
            val serial = display.nextSerial()
            keyboardsOf(old.resource.client).forEach { it.sendLeave(serial, old.resource) }
        }
        if (surface != null) {
            val serial = display.nextSerial()
            val keys = pressedKeysArray()
            for (keyboard in keyboardsOf(surface.resource.client)) {
                keyboard.sendEnter(serial, surface.resource, keys)
                sendModifiers(keyboard)
            }
            inputSent(surface.resource.client, serial)
            watchForDestruction(surface)
        }
        keyboardFocusListeners.forEach { it(surface) }
    }

    /** A key was pressed or released ([evdevCode] = Linux key code, e.g. 30 for A). */
    fun key(timeMillis: Int, evdevCode: Int, pressed: Boolean) {
        if (pressed) pressedKeys += evdevCode else pressedKeys -= evdevCode
        val modifiersChanged = keyboardState.update(evdevCode, pressed)
        val focus = keyboardFocus?.takeIf(::allowed) ?: return
        val serial = display.nextSerial()
        val state = if (pressed) WlKeyboard.KeyState.PRESSED else WlKeyboard.KeyState.RELEASED
        for (keyboard in keyboardsOf(focus.resource.client)) {
            keyboard.sendKey(serial, timeMillis, evdevCode, state)
            if (modifiersChanged) sendModifiers(keyboard)
        }
        inputSent(focus.resource.client, serial)
    }

    /**
     * Gives programs another keymap (other layouts, options): every keyboard gets it at once.
     * Num Lock and the layout in use stay as they were (the layout if the new keymap has it),
     * and keys held down stay held (Super held while the keymap changes is still Super).
     * The seat owns [next] from now on and closes the keymap it replaces (closing it again
     * yourself does no harm).
     */
    fun setKeymap(next: Keymap) {
        require(next.isOpen) { "The keymap was already closed" }
        if (next === keymap) return
        val before = keyboardState.modifiers
        val state = next.newState()
        // The keys held down now are held in the new state too (else their modifiers were lost
        // until let go, and the release came for a key the new state never saw pressed).
        for (code in pressedKeys) state.update(code, true)
        state.setLocks(before.locked, if (before.group < next.layoutCount) before.group else 0)
        keyboardState.close()
        keyboardState = state
        val old = keymap
        keymap = next
        for (keyboard in keyboards) sendKeymap(keyboard)
        keyboardFocus?.let { focus -> for (keyboard in keyboardsOf(focus.resource.client)) sendModifiers(keyboard) }
        // (Only now: every keyboard has the new one; the old one's file was copied for those still waiting to read it.)
        old.close()
        keyboardLog.trace { "Keymap replaced (${next.layoutCount} layouts), sent to ${keyboards.size} keyboards" }
    }

    // The keymap in use, to one keyboard.
    private fun sendKeymap(keyboard: WlKeyboard) =
        keyboard.sendKeymap(WlKeyboard.KeymapFormat.XKB_V1, keymap.shared.fd, keymap.sharedSize)

    /** The keyboard layout in use: 0 for the keymap's first ("us" of "us,ru"). */
    val layoutIndex: Int get() = keyboardState.modifiers.group

    /** How many layouts the keymap has. */
    val layoutCount: Int get() = keymap.layoutCount

    /** Switches to the layout [index] (counting around: one past the last is the first). */
    fun setLayout(index: Int) {
        if (!keyboardState.setLocks(keyboardState.modifiers.locked, Math.floorMod(index, layoutCount.coerceAtLeast(1)))) return
        keyboardFocus?.let { focus -> for (keyboard in keyboardsOf(focus.resource.client)) sendModifiers(keyboard) }
    }

    /** True if programs were told [evdevCode] is pressed (and not yet that it was let go). */
    fun holds(evdevCode: Int): Boolean = evdevCode in pressedKeys

    /**
     * A key the compositor kept for itself (a binding): the keyboard's state follows it all
     * the same — a layout switch on it ("grp:win_space_toggle"), Caps Lock — but no program
     * gets the key.
     */
    fun trackKey(evdevCode: Int, pressed: Boolean) {
        if (!keyboardState.update(evdevCode, pressed)) return
        keyboardFocus?.let { focus -> for (keyboard in keyboardsOf(focus.resource.client)) sendModifiers(keyboard) }
    }

    /** Turns Num Lock on or off, as if its key was pressed (the program with the keyboard is told). */
    fun setNumLock(on: Boolean) {
        if (!keyboardState.setNumLock(on)) return
        val focus = keyboardFocus ?: return
        for (keyboard in keyboardsOf(focus.resource.client)) sendModifiers(keyboard)
    }

    /** The character [evdevCode] types now (layout, Shift, AltGr), or null: none (for the compositor's own text fields). */
    fun textOf(evdevCode: Int): String? = keyboardState.text(evdevCode)

    /** The character [evdevCode] types in layout number [layout] (with Shift or not), whatever is held now; null: none. */
    fun textIn(evdevCode: Int, layout: Int, shift: Boolean): String? = keyboardState.textIn(evdevCode, Math.floorMod(layout, layoutCount.coerceAtLeast(1)), shift)

    /** True while Caps Lock is on (locked; not with "caps:super" and the like, where the key is no Caps Lock). */
    val capsLock: Boolean get() = keyboardState.modifiers.locked and 2 != 0

    /** The name of the symbol [evdevCode] means for shortcuts: Latin whatever the layout ("d" for the key of "в"; see [KeyboardState.shortcutSymbol]). */
    fun shortcutName(evdevCode: Int): String = keySymbolName(keyboardState.shortcutSymbol(evdevCode, layoutCount))

    /**
     * The key of [KeyBindings] combinations [evdevCode] stands for now, for [KeyBindings.keyOf]:
     * a key that types a Latin letter, digit or punctuation mark (see [shortcutName]: on the
     * Russian layout what it types in the first Latin layout) is the key of that name in
     * [KeyBindings] — on a German keyboard the key printed Z is Super+Z's — and every other key
     * (F1, Return, the arrows, é) is itself. The row of digits stays where it is (on AZERTY its
     * keys type "&", "é", "'" without Shift: Super+1..9 are still those keys).
     */
    fun bindingKeyOf(evdevCode: Int): Int {
        if (evdevCode !in 1..0xff) return evdevCode
        val symbol = keyboardState.shortcutSymbol(evdevCode, layoutCount)
        // (Latin symbols are their characters: "d", "D", "/".)
        if (symbol !in 0x21..0x7e) return evdevCode
        val letter = symbol in 0x41..0x5a || symbol in 0x61..0x7a
        if (!letter && evdevCode in DIGIT_ROW) return evdevCode
        return KeyBindings.keyCode(symbol.toChar().toString()) ?: evdevCode
    }

    /** The name of the symbol [evdevCode] gives now ("h", "H", "Return", "XF86AudioMute"). */
    fun keysymName(evdevCode: Int): String = keySymbolName(keyboardState.symbol(evdevCode))

    /**
     * The modifier key [evdevCode] is with the user's keymap and options (Caps Lock is Super
     * with `caps:super`, Alt and Super swap with `altwin:swap_lalt_lwin`), or null: not one of
     * Ctrl, Alt, Shift, Super (Hyper counts as Super, Meta as Alt). For [KeyBindings.modifierOf].
     */
    // (What the key gives on its own: with Shift held, "grp:alt_shift_toggle" makes Alt
    // ISO_Next_Group, and Alt was then no modifier at all.)
    fun modifierOfKey(evdevCode: Int): KeyBindings.Modifier? = when (keyboardState.baseSymbol(evdevCode)) {
        0xffe1, 0xffe2 -> KeyBindings.Modifier.SHIFT
        0xffe3, 0xffe4 -> KeyBindings.Modifier.CTRL
        0xffe7, 0xffe8, 0xffe9, 0xffea -> KeyBindings.Modifier.ALT
        0xffeb, 0xffec, 0xffed, 0xffee -> KeyBindings.Modifier.SUPER
        else -> null
    }

    /** The modifiers held or locked now (xkb bits: 1 Shift, 4 Ctrl, 8 Alt, 64 Logo). */
    val modifierBits: Int get() = keyboardState.modifiers.let { it.depressed or it.latched or it.locked }

    /** Releases every key, e.g. when Caulis's own window loses the keyboard. */
    fun releaseAllKeys(timeMillis: Int) {
        for (code in pressedKeys.toList()) key(timeMillis, code, pressed = false)
    }

    private fun sendModifiers(keyboard: WlKeyboard) {
        val m = keyboardState.modifiers
        val serial = display.nextSerial()
        keyboard.sendModifiers(serial, m.depressed, m.latched, m.locked, m.group)
        // (Programs answer Ctrl+C with the serial of whatever came last: this too.)
        if (keyboardFocus?.resource?.client === keyboard.client) inputSent(keyboard.client, serial)
    }

    // Surfaces we already watch, so focusing one many times does not add many listeners.
    private val watched = HashSet<Surface>()

    // When a focused surface goes away, nothing should stay focused on it.
    internal fun watchForDestruction(surface: Surface) {
        if (!watched.add(surface)) return
        surface.resource.onDestroy {
            watched -= surface
            if (keyboardFocus === surface) {
                // Through focusKeyboard, so the clipboard and the rest hear of it; then the
                // window manager gives the keyboard to whoever is next.
                focusLog.trace { "The surface with the keyboard was destroyed" }
                focusKeyboard(null)
                keyboardFocusDestroyed(surface)
            }
            if (pointerFocus === surface) pointerFocus = null
            if (penFocus === surface) penFocus = null
            if (cursorSurface === surface) cursorSurface = null
        }
    }

    private fun keyboardsOf(client: Client) = keyboards.filter { it.client === client }

    private fun pressedKeysArray(): ByteArray {
        val bytes = ByteBuffer.allocate(pressedKeys.size * 4).order(ByteOrder.nativeOrder())
        pressedKeys.forEach { bytes.putInt(it) }
        return bytes.array()
    }

    /** Ends a group of pointer events for the program under the pointer (after relative motion alone). */
    fun pointerFrame() = pointerSide.pointerFrame()

    /**
     * The pointer moved. [under] is what is under it now (null = nothing), [unitX], [unitY]
     * the position inside that surface. Sends leave/enter when the surface changes.
     */
    fun pointerMotion(timeMillis: Int, under: Surface?, unitX: Double, unitY: Double) = pointerSide.pointerMotion(timeMillis, under, unitX, unitY)

    // A drag and drop going on (wl_data_device.start_drag): the pointer's moves and the
    // button let go go to it instead of to programs' pointers.
    internal interface Drag {
        // The picture dragged along under the cursor, and where it is from the pointer.
        val icon: Surface?
        val iconX: Int
        val iconY: Int
        fun motion(timeMillis: Int, surface: Surface?, x: Double, y: Double)
        fun drop()
        fun cancel()
    }

    /** A mouse button changed ([button] = Linux code, e.g. 272 = left). */
    fun pointerButton(timeMillis: Int, button: Int, pressed: Boolean) = pointerSide.pointerButton(timeMillis, button, pressed)

    /**
     * Scrolling as 0.1.1 had it: [value] units along one axis, [value120] the wheel's steps in
     * 1/120 (a full notch = 120; 0: fingers).
     */
    @Deprecated("Give a Scroll (where it came from, notches in 1/120)", ReplaceWith("pointerAxis(timeMillis, Scroll(...))"))
    fun pointerAxis(timeMillis: Int, vertical: Boolean, value: Double, value120: Int) = pointerSide.pointerAxis(timeMillis, vertical, value, value120)

    /**
     * Scrolling (see [Scroll]): one group of events (a frame) for the program under the
     * pointer, as much as its wl_pointer version knows — where the scroll came from, the
     * wheel's notches (in 1/120 or in whole steps), the fingers stopping, natural scrolling.
     */
    fun pointerAxis(timeMillis: Int, scroll: Scroll) = pointerSide.pointerAxis(timeMillis, scroll)

    /** The program of [surface] listens to touches (else the compositor lets the finger be the pointer). */
    fun takesTouch(surface: Surface): Boolean = touches.any { it.client === surface.resource.client }

    /** A finger [id] touches [surface] at ([unitX], [unitY]) of it. */
    fun touchDown(timeMillis: Int, surface: Surface, id: Int, unitX: Double, unitY: Double) = touchSide.touchDown(timeMillis, surface, id, unitX, unitY)

    /** Finger [id] moved to ([unitX], [unitY]) of the surface it went down on. */
    fun touchMotion(timeMillis: Int, id: Int, unitX: Double, unitY: Double) = touchSide.touchMotion(timeMillis, id, unitX, unitY)

    /** Finger [id] lifted. */
    fun touchUp(timeMillis: Int, id: Int) = touchSide.touchUp(timeMillis, id)

    /** The end of a group of touch events (sent to the programs that had some). */
    fun touchFrame() = touchSide.touchFrame()

    /** The touches are not the programs' any more (a gesture of the compositor took them). */
    fun touchCancel() = touchSide.touchCancel()

    override fun close() {
        keyboardState.close()
        keymap.close()
    }

    companion object {
        const val VERSION = 9

        // How many of a program's last input serials still count (see isInputSerial): enough
        // for a program that answers a little late, after a few more keys.
        private const val INPUT_SERIALS = 16

        // The keys 1 to 0, minus and equal (see bindingKeyOf).
        private val DIGIT_ROW = 2..13

        /** Key repeat by default: characters per second and delay before repeating, in milliseconds. */
        const val REPEAT_RATE = 30
        const val REPEAT_DELAY = 300
    }
}

internal val focusLog = dev.caulis.log.Logger("focus")
internal val keyboardLog = dev.caulis.log.Logger("keyboard")
