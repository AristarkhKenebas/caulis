package dev.caulis.core

import dev.caulis.ffi.Fd
import dev.caulis.ffi.SharedMemory
import dev.caulis.ffi.SharedMemoryException
import dev.caulis.protocol.Display
import dev.caulis.protocol.wayland.WlBuffer
import dev.caulis.protocol.wayland.WlShm
import dev.caulis.protocol.wayland.WlShmPool

/**
 * wl_shm: clients draw into shared memory and hand it to the compositor as buffers.
 *
 * Everything a client says about that memory is checked: offsets, sizes and strides must
 * stay inside the memory it actually shared (computed in Long, so huge numbers cannot
 * wrap around), and the memory itself is mapped safely ([SharedMemory]).
 */
class Shm(display: Display) {

    /**
     * The widest and tallest picture a program may share, in pixels (16384 by default, what
     * GPUs show at most). A bigger one is refused when the program makes it (it would cost
     * gigabytes to copy, and no GPU could show it); set it to your GPU's limit if it is lower.
     */
    var maxBufferSide: Int = MAX_BUFFER_SIDE
        set(value) {
            require(value in 1..MAX_BUFFER_SIDE) { "maxBufferSide is 1 to $MAX_BUFFER_SIDE, not $value" }
            field = value
        }

    init {
        display.addGlobal(WlShm, VERSION) { shm ->
            shm.requests = requests
            for (format in FORMATS) shm.sendFormat(format)
        }
    }

    private val requests = object : WlShm.Requests {
        override fun createPool(resource: WlShm, id: WlShmPool, fd: Fd, size: Int) {
            if (size <= 0) {
                fd.close()
                resource.postError(WlShm.Error.INVALID_STRIDE, "pool size must be positive, got $size")
                return
            }
            val memory = try {
                mapPool(fd, size.toLong())
            } catch (e: Exception) {
                resource.postError(WlShm.Error.INVALID_FD, "cannot use the shared memory: ${e.message}")
                return
            }
            ShmPool(id, memory, this@Shm)
        }

        override fun release(resource: WlShm) {}
    }

    companion object {
        const val VERSION = 2

        /** Pixel formats every compositor must support. */
        val FORMATS = listOf(WlShm.Format.ARGB8888, WlShm.Format.XRGB8888)

        const val BYTES_PER_PIXEL = 4

        /** The default (and largest) [maxBufferSide]. */
        const val MAX_BUFFER_SIDE = 16384
    }
}

/**
 * A piece of shared memory a client gave us; buffers are rectangles inside it.
 * The memory is released when the pool and all its buffers are gone.
 */
class ShmPool internal constructor(resource: WlShmPool, private var memory: SharedMemory, private val shm: Shm) {

    private var users = 1 // the pool itself + every buffer made from it

    init {
        resource.requests = object : WlShmPool.Requests {
            override fun createBuffer(
                resource: WlShmPool, id: WlBuffer, offset: Int, width: Int, height: Int, stride: Int, format: Int,
            ) {
                if (format !in Shm.FORMATS) {
                    resource.postError(WlShm.Error.INVALID_FORMAT, "unsupported format $format")
                    return
                }
                if (width <= 0 || height <= 0 || offset < 0 || stride < width.toLong() * Shm.BYTES_PER_PIXEL) {
                    resource.postError(WlShm.Error.INVALID_STRIDE, "invalid buffer ${width}x$height stride $stride offset $offset")
                    return
                }
                if (width > shm.maxBufferSide || height > shm.maxBufferSide) {
                    resource.postError(WlShm.Error.INVALID_STRIDE, "buffer ${width}x$height is bigger than ${shm.maxBufferSide} pixels on a side")
                    return
                }
                val end = offset.toLong() + stride.toLong() * height
                if (end > memory.size) {
                    resource.postError(WlShm.Error.INVALID_STRIDE, "buffer ends at byte $end, pool has ${memory.size}")
                    return
                }
                users++
                ShmBuffer(id, this@ShmPool, offset.toLong(), width, height, stride, format)
            }

            override fun destroy(resource: WlShmPool) {}

            override fun resize(resource: WlShmPool, size: Int) {
                if (size < memory.size) {
                    resource.postError(WlShm.Error.INVALID_STRIDE, "pools can only grow ($size < ${memory.size})")
                    return
                }
                // Map the same memory again with the new size.
                val bigger = try {
                    mapPool(memory.fd.duplicate(), size.toLong())
                } catch (e: SharedMemoryException) {
                    resource.postError(WlShm.Error.INVALID_FD, "cannot resize: ${e.message}")
                    return
                }
                memory.close()
                memory = bigger
            }
        }
        resource.onDestroy { release() }
    }

    /** Runs [action] with the pool's memory (a misbehaving client causes [SharedMemoryException]). */
    fun <T> read(action: (java.lang.foreign.MemorySegment) -> T): T = memory.read(action)

    /** True if we may write into it (screenshots go there); false if the client gave it read-only. */
    val writable: Boolean get() = memory.writable

    /** Like [read], but to write into the pool (a screenshot). Only if [writable]. */
    fun <T> write(action: (java.lang.foreign.MemorySegment) -> T): T = memory.write(action)

    internal fun release() {
        if (--users == 0) memory.close()
    }
}

/** A client's picture: [width]x[height] pixels at [offset] in a [ShmPool]. */
class ShmBuffer internal constructor(
    val resource: WlBuffer,
    val pool: ShmPool,
    val offset: Long,
    override val width: Int,
    override val height: Int,
    val stride: Int,
    val format: Int,
) : ClientBuffer {
    init {
        resource.data = this
        resource.requests = object : WlBuffer.Requests {
            override fun destroy(resource: WlBuffer) {}
        }
        resource.onDestroy { pool.release() }
    }
}

// A client's pool, writable if the client allows it (screenshots are written into pools).
private fun mapPool(fd: Fd, size: Long): SharedMemory {
    val copy = fd.duplicate()
    return try {
        SharedMemory.map(copy, size, writable = true).also { fd.close() }
    } catch (_: Exception) {
        SharedMemory.map(fd, size) // read-only: fine for pictures, not for screenshots
    }
}
