package dev.caulis.core

import dev.caulis.event.EventLoop
import dev.caulis.geometry.Rect
import dev.caulis.log.Logger
import dev.caulis.render.Color
import dev.caulis.render.GpuTexture
import dev.caulis.render.Renderer
import java.awt.GradientPaint
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.nio.file.Path
import javax.imageio.ImageIO
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * The desktop's backgrounds ([Background]) on each monitor: their pictures on the GPU,
 * pictures read from files in the background, moving shaders drawn again as often as they
 * ask (only while they are seen), and a soft change from one background to the next.
 * Belongs to a [Desktop].
 */
internal class Backdrops(
    private val renderer: Renderer,
    private val loop: EventLoop,
    /** Something to draw changed. */
    private val changed: () -> Unit,
    /** A shader was drawn (problem null) or could not be (see Desktop.shaderWorks). */
    private val shaderWorks: (name: String, code: String, problem: String?) -> Unit = { _, _, _ -> },
    /** What wallpaper shaders share: their clock, the pointer, their frames. */
    private val shaders: ShaderWallpapers = ShaderWallpapers(loop, changed),
) {
    private val log = Logger("render")

    var background: Background = Background.USUAL
        set(value) {
            field = value
            changed()
        }

    var backgroundFor: ((Monitor, Int) -> Background?)? = null
        set(value) {
            field = value
            changed()
        }

    /** How long one background takes to melt into the next. */
    var changeMillis = 400L

    /** The melting's settings, given its usual time ([changeMillis]); the desktop's "fadeBackground" animation. */
    var fade: (Long) -> ResolvedAnimation = { ResolvedAnimation("fadeBackground", true, it, Curve.SMOOTH, null) }

    private fun backgroundOf(monitor: Monitor, workspace: Int): Background = try {
        backgroundFor?.invoke(monitor, workspace) ?: background
    } catch (e: Throwable) {
        e.rethrowIfFatal()
        log.error("Your backgroundFor failed (the usual background is shown): $e", e)
        background
    }

    // What each monitor showed last, and the one before while it melts away (since when).
    private val shown = HashMap<String, Background>()
    private val leaving = HashMap<String, Pair<Background, Long>>()

    /**
     * The items that draw [monitor]'s background now (below everything); [desktop] is all
     * monitors together (for backgrounds spanning them), [largestScale] the finest monitor's.
     */
    fun items(monitor: Monitor, workspace: Int, pointerX: Double, pointerY: Double, now: Long, desktop: Rect, largestScale: Double): List<DrawItem> {
        this.desktop = desktop
        this.largestScale = largestScale
        val wanted = backgroundOf(monitor, workspace)
        val before = shown.put(monitor.name, wanted)
        val melt = fade(changeMillis)
        if (before != null && before != wanted && melt.on) leaving[monitor.name] = before to now
        val items = ArrayList<DrawItem>(2)
        items += item(monitor, workspace, wanted, 1f, pointerX, pointerY, now, "background ${monitor.name}")
        leaving[monitor.name]?.let { (old, since) ->
            val t = (now - since) / (melt.effectiveMillis.coerceAtLeast(1) * 1_000_000.0)
            if (t >= 1.0 || !melt.on) {
                leaving -= monitor.name
            } else {
                val alpha = try { 1 - melt.curve.at(t) } catch (e: Exception) { 1 - t }
                items += item(monitor, workspace, old, alpha.toFloat().coerceIn(0f, 1f), pointerX, pointerY, now, "background before ${monitor.name}")
            }
        }
        return items
    }

    // All monitors together, and the finest scale (for pictures and shaders spanning them).
    private var desktop = Rect(0, 0, 1, 1)
    private var largestScale = 1.0

    /** True while a background melts into the next one: each frame is different. */
    fun changing(): Boolean = leaving.isNotEmpty()

    // The part of each monitor's background shown (Desktop.setBackgroundView), by monitor name.
    internal val views = HashMap<String, BackgroundView>()

    private fun item(monitor: Monitor, workspace: Int, background: Background, alpha: Float, pointerX: Double, pointerY: Double, now: Long, key: String): DrawItem {
        val area = monitor.area
        val pixels = monitor.pixelWidth to monitor.pixelHeight
        val view = views[monitor.name]
        val viewPart = view?.let { floatArrayOf(it.x.toFloat(), it.y.toFloat(), it.width.toFloat(), it.height.toFloat()) }
        return when (background) {
            is Background.Solid -> DrawItem.Custom(key, area, listOf(background, alpha), background = true) { r -> fill(r, background.color, alpha) }
            is Background.Gradient, is Background.Painted -> {
                val texture = painted(background, monitor, workspace)
                DrawItem.Custom(key, area, listOf(background, texture, alpha, view), background = true) { r ->
                    if (texture != null) renderer.drawTexture(texture, r.x, r.y, r.width, r.height, opaque = false, alpha = alpha, source = viewPart) else fill(r, USUAL_COLOR, alpha)
                }
            }
            is Background.Image -> {
                val picture = picture(background.path)
                val over = if (background.span) desktop else area
                val unitScale = if (background.span) largestScale else monitor.scale
                if (view != null) {
                    // The view's part of the whole picture, over the monitor.
                    DrawItem.Custom(key, area, listOf(background, picture, alpha, pixels, view), background = true) { r ->
                        if (picture == null) fill(r, background.behind, alpha) else renderer.drawTexture(picture.texture, r.x, r.y, r.width, r.height, opaque = false, alpha = alpha, source = viewPart)
                    }
                } else {
                    DrawItem.Custom(key, area, listOf(background, picture, alpha, pixels, over, unitScale), background = true) { r -> drawImage(r, area, over, unitScale, background, picture, alpha) }
                }
            }
            is Background.Shader -> {
                val shader = background.shader
                val picture = shader.image?.let(::picture)
                shaders.item(
                    key, renderer, monitor, area, shader, alpha, pointerX, pointerY, now, desktop, workspace, view, picture?.texture,
                    look = listOf(background, pixels, desktop), works = shaderWorks,
                )
            }
        }
    }

    private fun fill(r: Rect, color: Color, alpha: Float) = renderer.drawColor(r.x, r.y, r.width, r.height, color.red, color.green, color.blue, color.alpha * alpha)

    // --- pictures from files: read in the background, then on the GPU --------------------------

    private class Picture(val texture: GpuTexture, val width: Int, val height: Int)

    // By file: its picture, or null while it is read (or when it could not be).
    private val pictures = HashMap<Path, Picture?>()

    // Picture files followed for changes (a new version is read again), and when each was
    // last drawn (one not drawn for a while is let go: a slideshow does not pile up pictures).
    private val followed = HashMap<Path, AutoCloseable>()
    private val lastUsed = HashMap<Path, Long>()

    // Each reading of a file has a number: a slow older one never replaces a newer one.
    private val readings = HashMap<Path, Int>()

    private fun picture(path: Path): Picture? {
        lastUsed[path] = System.nanoTime()
        if (path in pictures) return pictures[path]
        pictures[path] = null
        val reading = (readings[path] ?: 0) + 1
        readings[path] = reading
        if (path !in followed) {
            followed[path] = FileWatch.watch(path) {
                loop.post {
                    if (path !in followed) return@post
                    pictures.remove(path)?.texture?.close()
                    changed()
                }
            }
        }
        Thread.ofVirtual().name("background-image").start {
            // (Also errors: Java's 2D graphics that cannot start says so with one; the background
            // then stays [Background.Image.behind], and the log says why.)
            val argb = try {
                val image = ImageIO.read(path.toFile()) ?: error("not a picture Java can read (PNG, JPEG, BMP, GIF)")
                BufferedImage(image.width, image.height, BufferedImage.TYPE_INT_ARGB_PRE).also { argb ->
                    argb.createGraphics().apply { drawImage(image, 0, 0, null); dispose() }
                }
            } catch (e: Throwable) {
                log.warn("The background picture $path could not be read: ${e.message ?: e}")
                return@start
            }
            loop.post {
                // Read again meanwhile (the file was saved), or let go: this one is not needed.
                if (readings[path] != reading || path !in pictures) return@post
                pictures.put(path, Picture(upload(argb), argb.width, argb.height))?.texture?.close()
                log.info { "Background picture $path: ${argb.width}x${argb.height}" }
                changed()
            }
        }
        return null
    }

    // Draws [picture] placed over [over] (desktop units: the monitor's [area], or all monitors
    // together) as [Background.Image.fit] says: the part on this monitor, into its pixels [r].
    // [unitScale]: picture pixels per unit at its own size (CENTER, TILE).
    private fun drawImage(r: Rect, area: Rect, over: Rect, unitScale: Double, background: Background.Image, picture: Picture?, alpha: Float) {
        if (picture == null) return fill(r, background.behind, alpha)
        val iw = picture.width.toDouble()
        val ih = picture.height.toDouble()
        val ow = over.width.toDouble()
        val oh = over.height.toDouble()
        // Where the whole picture is, in desktop units (x, y, width, height).
        fun centered(w: Double, h: Double) = doubleArrayOf(over.x + (ow - w) / 2, over.y + (oh - h) / 2, w, h)
        val fit = background.fit
        if (fit != Background.Fit.FILL && fit != Background.Fit.STRETCH) fill(r, background.behind, alpha)
        when (fit) {
            Background.Fit.FILL -> max(ow / iw, oh / ih).let { s -> part(r, area, picture, centered(iw * s, ih * s), alpha) }
            Background.Fit.FIT -> min(ow / iw, oh / ih).let { s -> part(r, area, picture, centered(iw * s, ih * s), alpha) }
            Background.Fit.STRETCH -> part(r, area, picture, doubleArrayOf(over.x.toDouble(), over.y.toDouble(), ow, oh), alpha)
            Background.Fit.CENTER -> part(r, area, picture, centered(iw / unitScale, ih / unitScale), alpha)
            Background.Fit.TILE -> {
                val tw = iw / unitScale
                val th = ih / unitScale
                // Only the tiles touching this monitor.
                var ty = over.y + Math.floor((area.y - over.y) / th) * th
                while (ty < area.bottom) {
                    var tx = over.x + Math.floor((area.x - over.x) / tw) * tw
                    while (tx < area.right) {
                        part(r, area, picture, doubleArrayOf(tx, ty, tw, th), alpha)
                        tx += tw
                    }
                    ty += th
                }
            }
        }
    }

    // The part of [picture] placed at [place] (desktop units) that is on the monitor [area], into its pixels [r].
    private fun part(r: Rect, area: Rect, picture: Picture, place: DoubleArray, alpha: Float) {
        val (px, py, pw, ph) = place.toList()
        val left = max(px, area.x.toDouble())
        val top = max(py, area.y.toDouble())
        val right = min(px + pw, area.right.toDouble())
        val bottom = min(py + ph, area.bottom.toDouble())
        if (right <= left || bottom <= top) return
        val sx = r.width.toDouble() / area.width
        val sy = r.height.toDouble() / area.height
        val x0 = (r.x + (left - area.x) * sx).roundToInt()
        val y0 = (r.y + (top - area.y) * sy).roundToInt()
        val x1 = (r.x + (right - area.x) * sx).roundToInt()
        val y1 = (r.y + (bottom - area.y) * sy).roundToInt()
        if (x1 <= x0 || y1 <= y0) return
        val source = floatArrayOf(((left - px) / pw).toFloat(), ((top - py) / ph).toFloat(), ((right - left) / pw).toFloat(), ((bottom - top) / ph).toFloat())
        renderer.drawTexture(picture.texture, x0, y0, x1 - x0, y1 - y0, opaque = false, alpha = alpha, source = source)
    }

    // --- painted and gradients: once per size ----------------------------------------------------

    private val paintings = HashMap<String, Pair<Any, GpuTexture>>()

    private fun painted(background: Background, monitor: Monitor, workspace: Int): GpuTexture? {
        val width = monitor.pixelWidth.coerceAtLeast(1)
        val height = monitor.pixelHeight.coerceAtLeast(1)
        val shows = listOf(background, width, height, monitor.scale, if (background is Background.Painted) workspace else 0)
        val key = monitor.name + if (background is Background.Painted) " painted" else " gradient"
        paintings[key]?.let { (was, texture) -> if (was == shows) return texture else texture.close() }
        paintings.remove(key)
        val image = BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB_PRE)
        val g = image.createGraphics()
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY)
            when (background) {
                is Background.Gradient -> {
                    fun awt(c: Color) = java.awt.Color(c.red, c.green, c.blue, c.alpha)
                    val angle = background.degrees * PI / 180
                    val half = (max(width, height) / 2.0)
                    val cx = width / 2.0
                    val cy = height / 2.0
                    g.paint = GradientPaint(
                        (cx - cos(angle) * half).toFloat(), (cy - sin(angle) * half).toFloat(), awt(background.from),
                        (cx + cos(angle) * half).toFloat(), (cy + sin(angle) * half).toFloat(), awt(background.to),
                    )
                    g.fillRect(0, 0, width, height)
                }
                is Background.Painted -> background.painter.paint(g, BackgroundLook(width, height, monitor.scale, monitor.name, workspace))
                else -> {}
            }
        } catch (e: Throwable) {
            e.rethrowIfFatal()
            log.error("Painting the background failed (your BackgroundPainter?): $e", e)
        } finally {
            g.dispose()
        }
        return upload(image).also { paintings[key] = shows to it }
    }

    private fun upload(image: BufferedImage): GpuTexture {
        val texture = renderer.createTexture(image.width, image.height)
        java.lang.foreign.Arena.ofConfined().use { arena ->
            val data = (image.raster.dataBuffer as java.awt.image.DataBufferInt).data
            texture.upload(arena.allocateFrom(java.lang.foreign.ValueLayout.JAVA_INT, *data), 0, image.height)
        }
        return texture
    }

    // --- pictures not drawn for a while: let go -----------------------------------------------------

    /** The scene was built: pictures not drawn for a while are let go (read again if they come back). */
    fun sceneBuilt() {
        val now = System.nanoTime()
        for ((path, used) in lastUsed.toList()) {
            if (now - used < UNUSED_NANOS) continue
            lastUsed.remove(path)
            pictures.remove(path)?.texture?.close()
            followed.remove(path)?.close()
        }
    }

    /** [monitor] went away: its pictures go too (a monitor coming back paints them anew). */
    fun forget(monitor: String) {
        shown -= monitor
        leaving -= monitor
        for (key in paintings.keys.filter { it.startsWith("$monitor ") }) paintings.remove(key)?.second?.close()
    }

    fun close() {
        pictures.values.forEach { it?.texture?.close() }
        followed.values.forEach { it.close() }
        paintings.values.forEach { it.second.close() }
    }

    private companion object {
        // How long a picture nobody draws is kept.
        const val UNUSED_NANOS = 60_000_000_000L

        val USUAL_COLOR = (Background.USUAL as Background.Solid).color
    }
}
